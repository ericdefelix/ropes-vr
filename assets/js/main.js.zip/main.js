
var animate_welcome = function() {

  // Authentication Animation
    var bg = 'bg-',
        count = 0,
        prev,
        counterIncrement = 1,
        counter = setInterval(timer, 6000),
        $elem = $('.js_bg'),
        cur_class = bg + count,
        // m_count = 1,
        max = 4; // Change this value according to number of images
    // var $msg = $('#loaderMessage');

    function timer() {
        if ( count >= max ) {
            count = 1;
            prev =  count - 1;
            cur_class = bg + count;
            prev_class = bg + prev;
            $elem.addClass(cur_class);
            $elem.removeClass( bg + max);
        }
        else {
            count = count + counterIncrement;
            prev =  count - 1;
            cur_class = bg + count;
            prev_class = bg + prev;
            $elem.addClass(cur_class);
            $elem.removeClass(prev_class);
        }
    }

    if ($elem.length) {
        timer();
    }
    else {
        return false;
    }

}

var build_navigation = function() {
    var _init = 'welcome_screen',
        _cur = '',
        _prev = _cur,
        _history = [_init],
        generic_info = '',

        $trigger = $('*[data-target-screen]'),
        $prev = $('*[data-target-prev]'),
        $uno = $('#messageUno'),
        $global_ui = $('#header, #footer'),
        $validate = $('*[data-validate-form]'),
        $lastname = $('#validateLastName'),
        $back = $('*[data-back-to-form]'),
        $home = $('*[data-home]')

        ropes_is_valid = false,
        has_application = false,
        error_counter = 0,
        max_tries = 3,
        end_of_max_tries = max_tries + 1;

    // Set state for initial screen
    function set_init() {
        $global_ui.hide(); // Hide header and footer
        $('.btn-back, .btn-home').hide(); // Initially hide the controls
        $('*[data-section="'+ _init +'"]').show(); // Show initial screen
        $('*[data-section="'+ _init +'"]').siblings('*[data-section]').hide(); // Hide other sections
        $('.error').hide();
    }

    function display_global_ui() {
        $global_ui.show(); // Show header and footer

        $('*[data-section="welcome_screen"]')
        .velocity( {  translateX: ['-110%', 0], opacity: [ 0, 1] }, [1,.06,.51,.66], 500, function(){ 
            $('#sectionContainer').removeClass('m_zindex');
            $('*[data-section="welcome_screen"]').remove();
        })
        .velocity( { opacity: 0 },{ display: 'none',duration: 0 });
        set_screen_elements();
    }

    function show_nav() { $('.btn-back, .btn-home').velocity('transition.expandIn', { stagger: 250, delay: 250, duration: 150 }); }
    function hide_nav() { $('.btn-back, .btn-home').velocity('transition.shrinkOut', { stagger: 250, delay: 250, duration: 150 }); }

    function set_screen_elements(){
        var $msg = $('*[data-section="' + _cur + '"] .message');

        // Hide the back and home button if not needed
        // if(_history.length == 3 && _prev == 'initial_options') 
        if(_history.length == 3) show_nav();
        if(_history.length == 2) hide_nav();

        switch(_cur){

            case 'initial_options':
                $uno.html('<h4>Nice to meet you! My name is <strong>UNO</strong>.</h4>');
                $('*[data-section="'+ _prev +'"]').hide();
                _history.splice(2, _history.length - 2);
                hide_nav();
                break;

            case 'im_here_to_apply':
                $uno.html('<h6>Guess what? You can learn more about [24]7 offerings by going to <strong class="text-info">http://www.ropeswebsite.com</strong></h6>');
                break;

            case 'ropes_question':
                $uno.html('<h5>ROPES is our Recruitment Online Profiling Evaluation System</h5>');
                break;

            case 'ropes_details':
                $uno.html('<h6>Your ROPES credentials are your ROPES ID, Username and the email you used when you registered.</h6>');
                break;

            case 'company_overview':
                $uno.html('<h5>Here at [24]7, ASL stands for Anticipate, Simplify, and Learn.</h5>');
                break;

            case 'goodbye_user':
                $uno.html('<h4>Thank you for letting me help you out!</h4>');
                exit_greeting();
                break;

            case 'generic_info':
                switch(generic_info){
                    case 'ropes_not_registered':
                        $msg.html('<h5>Alright then. Head on over to our registration kiosk so you can start filling out the application form.</h5>');
                        break;
                    case 'no_application':
                        $msg.html('<h5>It seeems that you haven&apos;t made any application yet?  Please go to the registration kiosk, login to ROPES and submit your application.</h5>');
                        break;
                    case 'has_application':
                        $msg.html('<h5>Fantastic! Why don&apos;t you head on up to the 6th floor.  One of our friendly recruiters will call on you shortly.</h5>');
                        break;
                    case 'might_apply':
                        $msg.html('<h4>Come on up to the 6th floor!</h4>');
                        break;
                    default:
                        $msg.html(' --- ');
                        console.log('No information available');
                        break;
                }

                break;
            default:
                // console.log('No information available');
                break;
        }
    }

    function reset_errors() {
        $('*[data-section="'+ _cur +'"] .error').hide();
        $('*[data-section="'+ _prev +'"] .error').hide();
        $('*[data-section="'+ _prev +'"] .error .error-message').html('Hmm... Your last name didn&apos;t match your current record');
    }

    function show_errors() {
        // $('*[data-section="'+ _cur +'"] .error').show();
        $('*[data-section="'+ _cur +'"] .error').velocity({
            translateY: ['-50%','-50%'],
            scaleX: [1,0.9],
            scaleY: [1,0.9],
        },
        {
            display: 'block',
            easing: 'spring',
            duration: 1000
        });
        KEYBOARD.hide();
    }
    
    // Set current screen
    $trigger.on('click', function() {
        _cur = $(this).data('target-screen'); // Set target to current screen
        _history.push(_cur); // Update history
        _prev = _history[_history.length - 2]; // Get target for previous screen

        // Show target screen
        $('*[data-section="'+ _history[_history.length - 1] +'"]').show();
        $('*[data-section="'+ _history[_history.length - 1] +'"] .animate')
            .velocity('transition.slideRightIn', { 
                stagger: 250, delay: 250, duration: 500, display: 'block'
            });
        
        // Hide previous screen and display the header/footer
        _cur === 'initial_options' ? display_global_ui() : 

            $('*[data-section="'+ _prev +'"] .animate').velocity('reverse', 500, function(){ 
                set_screen_elements(); // Update elements
                $('*[data-section="'+ _prev +'"]').hide();
            });

        // If target is generic information, identify its specific target then update
        if (_cur === 'generic_info') generic_info = $(this).data('for');

        // Resets the view of the forms
        if ($(this).data('target-screen') == 'ropes_details') reset_errors();
        if ($(this).data('target-screen') == 'ropes_try_again') { 
            reset_errors();
            error_counter = 0;
        }

        console.log(_history);
        console.log('Cur screen is ' + _cur + ' | Prev screen is ' + _prev);
    });

    // Set previous screen
    $prev.on('click', function() {

        _cur = _history[_history.length - 2]; // Get target for previous screen
        _prev = _history[_history.length - 1]; // Get last screen shown
        
        if (_history.length > 2) {
            // Hide current screen
            $('*[data-section="'+ _prev +'"] .animate').velocity('reverse', 500, function(){ 
                $('*[data-section="'+ _prev +'"]').hide();
            });

            // Show previous screen
            $('*[data-section="'+ _cur +'"]').show();
            $('*[data-section="'+ _cur +'"] .animate')
                .velocity('transition.slideRightIn', { 
                    stagger: 250, delay: 250, duration: 500
                });

            _history.pop(); // Update history by removing last item

            // Update elements
            set_screen_elements();

            console.log(_history);
            console.log('Cur screen is ' + _cur + ' | Prev screen is ' + _prev);
        }
        else {
            return false;
        }
    });

    $validate.on('click', function() {
        var ropes_is_valid = confirm("Is ROPES Valid"); // Simulate form validation

        var form_screen = '*[data-section="'+_cur+'"] ';

        
        if (ropes_is_valid) {
            console.log('ROPES Credential is Valid');
            $(form_screen).find('*[data-target-screen="ropes_lastname"]').click();
        }

        else {

            error_counter++;

            if (error_counter == 1) {
                show_errors();
                $uno.html('<h6>Don&apos;t panic. Just check your spacing or spelling to make sure that you&apos;re entering the right information.</h6>');
            }

            else if (error_counter == (max_tries - 1)) {
                show_errors();
                $('section:visible').find('.error-message').html('We still can&apos;t find your information.');
                console.log('One last try');
            }

            else if (error_counter == max_tries) {
                show_errors();
                $('section:visible').find('.error-message').html('I&apos;m sorry but your information is still not found');
                console.log('Change error message');
            }

            else if (error_counter == end_of_max_tries) {
                $(form_screen).find('*[data-target-screen="ropes_try_again"]').click();
            }
        }
    });

    $lastname.on('click', function() {
        var has_application = confirm("User has application?"); // Simulate form validation

        var form_screen = '*[data-section="'+_cur+'"] ';

        if (has_application) {
            console.log('User has application');
            $(form_screen).find('*[data-for="has_application"]').click();
        }
        else {
            $(form_screen).find('*[data-for="no_application"]').click();
        }
    });

    // If error is present, goes back to the form
    $back.on('click', reset_errors);
    
    set_init(); //Initialize
}

function exit_greeting() {
    var today = new Date(),
        curHr = today.getHours(),
        $partOfDay = $('#partOfDay'),
        greeting = ['pleasant','wonderful','fine','lovely','good','lovely','nice'];

    if(curHr < 12) {
        $partOfDay.html('morning');
    }
    else if (curHr < 18) {
        $partOfDay.html('afternoon');
    }
    else {
        $partOfDay.html('evening');
    }

    var adjective = greeting[Math.floor((Math.random() * greeting.length) + 1)];
    $('#describeDay').html(adjective);    
}


$(document).ready(function() {
    animate_welcome();
    build_navigation();
});
